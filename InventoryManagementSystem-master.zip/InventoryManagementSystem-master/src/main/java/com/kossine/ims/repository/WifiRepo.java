package com.kossine.ims.repository;

import com.kossine.ims.models.Wifi;

public interface WifiRepo extends GenericRepo<Wifi>{

	

}
