package com.kossine.ims.repository;

import com.kossine.ims.models.Mouse;

public interface MouseRepo extends GenericRepo<Mouse>{

	

}
