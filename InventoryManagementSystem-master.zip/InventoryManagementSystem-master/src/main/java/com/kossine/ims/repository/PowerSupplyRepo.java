package com.kossine.ims.repository;

import com.kossine.ims.models.PowerSupply;

public interface PowerSupplyRepo extends GenericRepo<PowerSupply>{

	

}
