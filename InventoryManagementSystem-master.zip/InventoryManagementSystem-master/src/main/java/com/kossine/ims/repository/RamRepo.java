package com.kossine.ims.repository;

import com.kossine.ims.models.Ram;

public interface RamRepo extends GenericRepo<Ram>{

	

}
