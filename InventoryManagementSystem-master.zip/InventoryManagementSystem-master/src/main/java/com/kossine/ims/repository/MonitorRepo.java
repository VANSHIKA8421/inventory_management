package com.kossine.ims.repository;

import com.kossine.ims.models.Monitor;

public interface MonitorRepo extends GenericRepo<Monitor>{

	

}
