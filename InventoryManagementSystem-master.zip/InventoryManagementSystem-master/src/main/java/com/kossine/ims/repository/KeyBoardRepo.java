package com.kossine.ims.repository;

import com.kossine.ims.models.KeyBoard;

public interface KeyBoardRepo extends GenericRepo<KeyBoard>{

	

}
