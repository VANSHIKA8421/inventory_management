package com.kossine.ims.repository;

import com.kossine.ims.models.Hdd;

public interface HddRepo extends GenericRepo<Hdd>{

	

}
