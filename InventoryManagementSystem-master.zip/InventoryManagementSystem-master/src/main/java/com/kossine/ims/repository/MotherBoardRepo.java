package com.kossine.ims.repository;

import com.kossine.ims.models.MotherBoard;

public interface MotherBoardRepo extends GenericRepo<MotherBoard>{

	

}
