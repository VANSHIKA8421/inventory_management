--drop table laptop;
--drop table adapter;
delete from  laptop ;
delete from   adapter ;